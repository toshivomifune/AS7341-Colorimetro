/*
  COLORIMETRO AS7341 + TFT ST7796
  ESP32 generica de 30 pines

  Librerias:
  - DFRobot_AS7341
  - GFX Library for Arduino

  Monitor serial: 115200 baudios
*/

#include <Wire.h>
#include <Arduino_GFX_Library.h>
#include "DFRobot_AS7341.h"

#define AS7341_SDA 21
#define AS7341_SCL 22
#define NIVEL_LED 10

#define TFT_CS    5
#define TFT_RST   4
#define TFT_DC    2
#define TFT_MOSI 23
#define TFT_SCK  18
#define TFT_MISO 19

#define C_NEGRO       RGB565_BLACK
#define C_BLANCO      RGB565_WHITE
#define C_ROJO        RGB565_RED
#define C_VERDE       RGB565_GREEN
#define C_AZUL        RGB565_BLUE
#define C_AMARILLO    RGB565_YELLOW
#define C_CIAN        RGB565_CYAN
#define C_MAGENTA     RGB565_MAGENTA
#define C_GRIS        0x8410
#define C_GRIS_OSCURO 0x4208
#define C_NARANJA     0xFD20
#define C_VIOLETA     0x801F

Arduino_DataBus *bus = new Arduino_ESP32SPI(
  TFT_DC, TFT_CS, TFT_SCK, TFT_MOSI, TFT_MISO
);

Arduino_GFX *tft = new Arduino_ST7796(
  bus,
  TFT_RST,
  1,
  false
);

DFRobot_AS7341 sensor;

struct DatosEspectrales {
  uint16_t f1, f2, f3, f4;
  uint16_t f5, f6, f7, f8;
  uint16_t clear, nir;
};

struct ResultadoColor {
  const char *nombre;
  uint16_t colorPantalla;
  float rojo, verde, azul;
  float r, g, b;
  float saturacion;
};

DatosEspectrales leerAS7341();
DatosEspectrales leerPromedio(uint8_t muestras);
ResultadoColor detectarColor(const DatosEspectrales &d);
void dibujarInterfaz();
void actualizarPantalla(const DatosEspectrales &d, const ResultadoColor &resultado);
void dibujarBarras(const DatosEspectrales &d);
void mostrarSerial(const DatosEspectrales &d, const ResultadoColor &resultado);
uint16_t maximoEspectral(const DatosEspectrales &d);

void setup() {
  Serial.begin(115200);
  delay(1000);

  Wire.begin(AS7341_SDA, AS7341_SCL);
  Wire.setClock(100000);
  delay(200);

  while (sensor.begin() != 0) {
    Serial.println("AS7341 no detectado en 0x39");
    delay(1000);
  }

  sensor.setAtime(29);
  sensor.setAstep(599);
  sensor.setAGAIN(7);
  sensor.enableLed(true);
  sensor.controlLed(NIVEL_LED);

  tft->begin(20000000);
  tft->fillScreen(C_NEGRO);
  dibujarInterfaz();

  Serial.println();
  Serial.println("Colorimetro AS7341 iniciado");
  Serial.println("TFT ST7796: 480 x 320");
  Serial.println("AS7341: direccion 0x39");
}

void loop() {
  DatosEspectrales datos = leerPromedio(3);
  ResultadoColor resultado = detectarColor(datos);

  actualizarPantalla(datos, resultado);
  mostrarSerial(datos, resultado);

  delay(300);
}

DatosEspectrales leerAS7341() {
  DatosEspectrales d{};

  DFRobot_AS7341::sModeOneData_t grupo1;
  DFRobot_AS7341::sModeTwoData_t grupo2;

  sensor.startMeasure(sensor.eF1F4ClearNIR);
  grupo1 = sensor.readSpectralDataOne();

  sensor.startMeasure(sensor.eF5F8ClearNIR);
  grupo2 = sensor.readSpectralDataTwo();

  d.f1 = grupo1.ADF1;
  d.f2 = grupo1.ADF2;
  d.f3 = grupo1.ADF3;
  d.f4 = grupo1.ADF4;

  d.f5 = grupo2.ADF5;
  d.f6 = grupo2.ADF6;
  d.f7 = grupo2.ADF7;
  d.f8 = grupo2.ADF8;

  d.clear = grupo2.ADCLEAR;
  d.nir = grupo2.ADNIR;

  return d;
}

DatosEspectrales leerPromedio(uint8_t muestras) {
  if (muestras == 0) muestras = 1;

  uint32_t sf1 = 0, sf2 = 0, sf3 = 0, sf4 = 0;
  uint32_t sf5 = 0, sf6 = 0, sf7 = 0, sf8 = 0;
  uint32_t sclear = 0, snir = 0;

  for (uint8_t i = 0; i < muestras; i++) {
    DatosEspectrales d = leerAS7341();

    sf1 += d.f1; sf2 += d.f2; sf3 += d.f3; sf4 += d.f4;
    sf5 += d.f5; sf6 += d.f6; sf7 += d.f7; sf8 += d.f8;
    sclear += d.clear;
    snir += d.nir;
  }

  DatosEspectrales p;
  p.f1 = sf1 / muestras; p.f2 = sf2 / muestras;
  p.f3 = sf3 / muestras; p.f4 = sf4 / muestras;
  p.f5 = sf5 / muestras; p.f6 = sf6 / muestras;
  p.f7 = sf7 / muestras; p.f8 = sf8 / muestras;
  p.clear = sclear / muestras;
  p.nir = snir / muestras;

  return p;
}

ResultadoColor detectarColor(const DatosEspectrales &d) {
  ResultadoColor resultado{};

  resultado.azul = ((float)d.f2 + (float)d.f3) / 2.0f;
  resultado.verde = ((float)d.f4 + (float)d.f5) / 2.0f;
  resultado.rojo = ((float)d.f7 + (float)d.f8) / 2.0f;

  float amarillo = (float)d.f6;
  float suma = resultado.rojo + resultado.verde + resultado.azul;
  if (suma < 1.0f) suma = 1.0f;

  resultado.r = resultado.rojo / suma;
  resultado.g = resultado.verde / suma;
  resultado.b = resultado.azul / suma;

  float maximo = resultado.rojo;
  float minimo = resultado.rojo;

  if (resultado.verde > maximo) maximo = resultado.verde;
  if (resultado.azul > maximo) maximo = resultado.azul;
  if (resultado.verde < minimo) minimo = resultado.verde;
  if (resultado.azul < minimo) minimo = resultado.azul;

  resultado.saturacion = (maximo > 0.0f) ? (maximo - minimo) / maximo : 0.0f;

  float r = resultado.r;
  float g = resultado.g;
  float b = resultado.b;

  if (d.clear < 200) {
    resultado.nombre = "NEGRO";
    resultado.colorPantalla = C_NEGRO;
    return resultado;
  }

  if (resultado.saturacion < 0.14f) {
    if (d.clear > 3000) {
      resultado.nombre = "BLANCO";
      resultado.colorPantalla = C_BLANCO;
    } else {
      resultado.nombre = "GRIS";
      resultado.colorPantalla = C_GRIS;
    }
    return resultado;
  }

  if (r > 0.43f &&
      resultado.rojo > resultado.verde * 1.30f &&
      resultado.rojo > resultado.azul * 1.35f) {
    resultado.nombre = "ROJO";
    resultado.colorPantalla = C_ROJO;
    return resultado;
  }

  if (resultado.rojo > resultado.verde * 1.12f &&
      resultado.rojo < resultado.verde * 1.90f &&
      amarillo > resultado.azul * 1.30f &&
      b < 0.27f) {
    resultado.nombre = "NARANJA";
    resultado.colorPantalla = C_NARANJA;
    return resultado;
  }

  if (amarillo > resultado.azul * 1.40f &&
      resultado.rojo > resultado.azul * 1.15f &&
      resultado.verde > resultado.azul * 1.15f &&
      r > 0.29f && g > 0.29f) {
    resultado.nombre = "AMARILLO";
    resultado.colorPantalla = C_AMARILLO;
    return resultado;
  }

  if (g > 0.40f &&
      resultado.verde > resultado.rojo * 1.18f &&
      resultado.verde > resultado.azul * 1.12f) {
    resultado.nombre = "VERDE";
    resultado.colorPantalla = C_VERDE;
    return resultado;
  }

  if (b > 0.42f &&
      resultado.azul > resultado.verde * 1.18f &&
      resultado.azul > resultado.rojo * 1.28f) {
    resultado.nombre = "AZUL";
    resultado.colorPantalla = C_AZUL;
    return resultado;
  }

  if (g > 0.32f && b > 0.32f && r < 0.30f) {
    resultado.nombre = "CIAN";
    resultado.colorPantalla = C_CIAN;
    return resultado;
  }

  if (r > 0.31f && b > 0.31f && g < 0.30f) {
    if (resultado.azul > resultado.rojo * 1.15f) {
      resultado.nombre = "VIOLETA";
      resultado.colorPantalla = C_VIOLETA;
    } else {
      resultado.nombre = "MAGENTA";
      resultado.colorPantalla = C_MAGENTA;
    }
    return resultado;
  }

  if (resultado.rojo > resultado.verde &&
      resultado.rojo > resultado.azul) {
    resultado.nombre = "ROJIZO";
    resultado.colorPantalla = C_ROJO;
  } else if (resultado.verde > resultado.rojo &&
             resultado.verde > resultado.azul) {
    resultado.nombre = "VERDOSO";
    resultado.colorPantalla = C_VERDE;
  } else {
    resultado.nombre = "AZULADO";
    resultado.colorPantalla = C_AZUL;
  }

  return resultado;
}

void dibujarInterfaz() {
  tft->fillScreen(C_NEGRO);
  tft->fillRect(0, 0, 480, 40, C_GRIS_OSCURO);

  tft->setTextColor(C_BLANCO);
  tft->setTextSize(2);
  tft->setCursor(12, 12);
  tft->print("COLORIMETRO ESPECTRAL AS7341");

  tft->drawLine(0, 40, 479, 40, C_CIAN);

  tft->setTextColor(C_GRIS);
  tft->setCursor(15, 55);
  tft->print("COLOR DETECTADO");

  tft->drawRect(335, 50, 125, 88, C_BLANCO);
  tft->drawLine(0, 145, 479, 145, C_GRIS);
  tft->drawLine(318, 145, 318, 319, C_GRIS);

  tft->setTextColor(C_BLANCO);
  tft->setCursor(15, 154);
  tft->print("ESPECTRO F1 - F8");

  tft->setCursor(330, 154);
  tft->print("VALORES");

  tft->setCursor(330, 188); tft->print("CLR:");
  tft->setCursor(330, 215); tft->print("NIR:");
  tft->setCursor(330, 250); tft->print("R:");
  tft->setCursor(330, 275); tft->print("G:");
  tft->setCursor(330, 300); tft->print("B:");
}

void actualizarPantalla(const DatosEspectrales &d, const ResultadoColor &resultado) {
  tft->fillRect(10, 80, 315, 60, C_NEGRO);

  uint16_t colorTexto = resultado.colorPantalla;
  if (resultado.colorPantalla == C_NEGRO ||
      resultado.colorPantalla == C_AZUL) {
    colorTexto = C_BLANCO;
  }

  tft->setTextColor(colorTexto);
  tft->setTextSize(4);
  tft->setCursor(15, 96);
  tft->print(resultado.nombre);

  tft->fillRect(339, 54, 117, 80, resultado.colorPantalla);
  tft->drawRect(335, 50, 125, 88, C_BLANCO);

  if (resultado.colorPantalla == C_BLANCO) {
    tft->drawRect(340, 55, 115, 78, C_GRIS_OSCURO);
  }

  dibujarBarras(d);

  tft->fillRect(380, 180, 98, 140, C_NEGRO);
  tft->setTextColor(C_AMARILLO);
  tft->setTextSize(2);

  tft->setCursor(385, 188); tft->print(d.clear);
  tft->setCursor(385, 215); tft->print(d.nir);
  tft->setCursor(365, 250); tft->print(resultado.r, 2);
  tft->setCursor(365, 275); tft->print(resultado.g, 2);
  tft->setCursor(365, 300); tft->print(resultado.b, 2);
}

void dibujarBarras(const DatosEspectrales &d) {
  uint16_t canales[8] = {
    d.f1, d.f2, d.f3, d.f4,
    d.f5, d.f6, d.f7, d.f8
  };

  uint16_t colores[8] = {
    C_VIOLETA, C_AZUL, C_AZUL, C_CIAN,
    C_VERDE, C_AMARILLO, C_ROJO, C_ROJO
  };

  uint16_t valorMaximo = maximoEspectral(d);
  if (valorMaximo == 0) valorMaximo = 1;

  const int xInicial = 12;
  const int yBase = 292;
  const int anchoBarra = 24;
  const int separacion = 13;
  const int alturaMaxima = 100;

  tft->fillRect(5, 178, 308, 142, C_NEGRO);

  for (uint8_t i = 0; i < 8; i++) {
    int x = xInicial + i * (anchoBarra + separacion);
    int altura = ((uint32_t)canales[i] * alturaMaxima) / valorMaximo;

    if (altura < 1 && canales[i] > 0) altura = 1;

    tft->drawRect(
      x, yBase - alturaMaxima,
      anchoBarra, alturaMaxima,
      C_GRIS
    );

    tft->fillRect(
      x + 1, yBase - altura,
      anchoBarra - 2, altura,
      colores[i]
    );

    tft->setTextColor(C_BLANCO);
    tft->setTextSize(1);
    tft->setCursor(x + 5, 302);
    tft->print("F");
    tft->print(i + 1);
  }
}

uint16_t maximoEspectral(const DatosEspectrales &d) {
  uint16_t maximo = d.f1;

  if (d.f2 > maximo) maximo = d.f2;
  if (d.f3 > maximo) maximo = d.f3;
  if (d.f4 > maximo) maximo = d.f4;
  if (d.f5 > maximo) maximo = d.f5;
  if (d.f6 > maximo) maximo = d.f6;
  if (d.f7 > maximo) maximo = d.f7;
  if (d.f8 > maximo) maximo = d.f8;

  return maximo;
}

void mostrarSerial(const DatosEspectrales &d, const ResultadoColor &resultado) {
  Serial.println("-----------------------------------------");
  Serial.print("COLOR: ");
  Serial.println(resultado.nombre);

  Serial.print("F1: "); Serial.print(d.f1);
  Serial.print("  F2: "); Serial.print(d.f2);
  Serial.print("  F3: "); Serial.print(d.f3);
  Serial.print("  F4: "); Serial.println(d.f4);

  Serial.print("F5: "); Serial.print(d.f5);
  Serial.print("  F6: "); Serial.print(d.f6);
  Serial.print("  F7: "); Serial.print(d.f7);
  Serial.print("  F8: "); Serial.println(d.f8);

  Serial.print("CLEAR: "); Serial.print(d.clear);
  Serial.print("  NIR: "); Serial.println(d.nir);

  Serial.print("R: "); Serial.print(resultado.r, 3);
  Serial.print("  G: "); Serial.print(resultado.g, 3);
  Serial.print("  B: "); Serial.println(resultado.b, 3);
}
