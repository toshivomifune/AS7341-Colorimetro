# Instalación y uso

## 1. Instalar Arduino IDE

Usar Arduino IDE 2.x.

## 2. Instalar soporte para ESP32

En el Gestor de placas, instalar el paquete de Espressif para ESP32.

Seleccionar:

```text
Herramientas → Placa → esp32 → ESP32 Dev Module
```

## 3. Instalar librerías

Desde el Administrador de bibliotecas:

- DFRobot_AS7341
- GFX Library for Arduino

## 4. Abrir el programa

Abrir el archivo:

```text
firmware/V1_Identificacion_Color/Colorimetro_V1.ino
```

## 5. Compilar y cargar

- Seleccionar el puerto COM de la ESP32.
- Compilar.
- Cargar el programa.
- Abrir el monitor serial a 115200 baudios.

## 6. Uso

Mantener el sensor aproximadamente entre 1 y 2 cm del objeto, con distancia y ángulo constantes.
