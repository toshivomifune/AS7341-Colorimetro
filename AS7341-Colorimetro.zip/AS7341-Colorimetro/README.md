# Colorímetro Espectral AS7341 + ESP32 + TFT ST7796

Proyecto de un colorímetro espectral basado en:

- ESP32 DevKit V1 de 30 pines
- Sensor espectral DFRobot AS7341
- Pantalla TFT SPI ST7796 de 4 pulgadas, 480 × 320

## Funciones actuales

- Lectura de los 10 canales ópticos del AS7341
- Lectura de F1–F8, Clear y NIR
- Detección aproximada de colores
- Visualización del color detectado
- Gráfica de barras espectrales
- Salida por monitor serial

## Estructura del repositorio

```text
AS7341-Colorimetro/
├── README.md
├── LICENSE
├── CHANGELOG.md
├── .gitignore
├── firmware/
│   └── V1_Identificacion_Color/
│       └── Colorimetro_V1.ino
├── hardware/
│   └── CONEXIONES.md
├── docs/
│   └── INSTALACION.md
├── images/
└── data/
```

## Código del programa

El programa principal está en:

[`firmware/V1_Identificacion_Color/Colorimetro_V1.ino`](firmware/V1_Identificacion_Color/Colorimetro_V1.ino)

## Librerías necesarias

Instalar desde el Administrador de bibliotecas de Arduino IDE:

- `DFRobot_AS7341`
- `GFX Library for Arduino`

## Configuración de Arduino IDE

- Placa: `ESP32 Dev Module`
- Monitor serial: `115200 baudios`

## Conexiones

Consulta:

[`hardware/CONEXIONES.md`](hardware/CONEXIONES.md)

## Estado

Versión V1 funcional.

## Autor

Gustavo Adolfo Ramírez Piedrahita
