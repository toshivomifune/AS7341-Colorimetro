# Historial de cambios

## [1.0.0] - 2026-07-31

### Añadido

- Lectura de los 10 canales ópticos del AS7341.
- Detección inicial de colores.
- Integración con TFT ST7796 de 480 × 320.
- Gráfica de barras F1–F8.
- Lectura de Clear y NIR.
- Salida por monitor serial.
- Documentación inicial del repositorio.
