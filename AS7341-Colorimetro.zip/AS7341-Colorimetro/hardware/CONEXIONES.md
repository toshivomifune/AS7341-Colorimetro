# Conexiones

## AS7341 a ESP32

| AS7341 | ESP32 |
|---|---:|
| VCC | 3V3 |
| GND | GND |
| SDA / D | GPIO 21 |
| SCL / C | GPIO 22 |

## TFT ST7796 a ESP32

| TFT | ESP32 |
|---|---:|
| VCC | 5V |
| GND | GND |
| CS | GPIO 5 |
| RESET | GPIO 4 |
| DC/RS | GPIO 2 |
| SDI/MOSI | GPIO 23 |
| SCK | GPIO 18 |
| LED | 3V3 |
| SDO/MISO | GPIO 19 |

## Notas

- Todos los módulos deben compartir GND.
- El AS7341 usa I²C.
- La TFT usa SPI.
- Los pines del touch y de la microSD no se usan en esta versión.
